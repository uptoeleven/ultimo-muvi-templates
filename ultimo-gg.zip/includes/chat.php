<div class="d-flex mb-3">
    <img src="images/user-image.jpg" class="rounded-circle chat-user-img">
    <div class="d-flex justify-content-between mt-1 ml-2">
        <div class="font-bold">Gamertag:</div>
        <div class="ml-2">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod</div>
    </div>
</div>