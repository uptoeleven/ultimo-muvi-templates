<div class="col-sm-6 col-md-3 mb-4 text-uppercase">
    <div class="position-relative">
        <div class="position-absolute w-100 h-100 stream-img-overlay"></div>
        <img src="images/stream-cat-img-04.jpg" class="img-responsive">
        <div class="position-absolute live-badge">
            <img src="images/icons/streaming-red.svg">
            <span>Live</span>
        </div>
    </div>
    <div class="spacer1 mb-1"></div>
    <div class="d-flex flex-between mb-2">
        <div class="font-bold">Stream name here</div>
        <a class="text-reset" href="#">
        <i class="fa fa-ellipsis-v" aria-hidden="true"></i>
        </a>
    </div>
    <h6 class="gamer-tag font-bold">Gamertag1</h6>
    <div class="viewers-text my-2 font-xxs">1,205 viewers</div>
    <div class="d-flex flex-between">
        <div>
            <span class="tag label">Tag 1</span>
            <span class="tag label">Tag 1</span>
            <span class="tag label">Tag 1</span>
        </div>
        <div class="d-flex align-items-center like font-sm">
            <img class="mr-2" src="images/icons/flame.svg">
            <div class="font-bold">538</div>
        </div>
    </div>
</div>