<div class="position-relative">
    <div class="position-absolute w-100 h-100 stream-img-overlay"></div>
    <img src="images/stream-cat-img-01.jpg" alt="">
    <div class="position-absolute live-badge">
        <img src="images/icons/streaming-red.svg">
        <span>Live</span>
    </div>
    <a href="#" class="stretched-link"></a>
</div>