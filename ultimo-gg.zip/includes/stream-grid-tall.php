<div class="col-sm-4 col-md-2 mb-4 text-uppercase">
    <img src="images/stream-cat-tall-img-01.jpg" class="img-responsive w-100">
    <div class="spacer1"></div>
    <div class="d-flex flex-between mb-2">
        <div class="font-bold">Game name</div>
        <a class="text-reset" href="#">
        <i class="fa fa-ellipsis-v" aria-hidden="true"></i>
        </a>
    </div>
    <div class="viewers-text font-xxs mb-2">1,205 viewers</div>
    <div>
        <span class="tag label">Tag 1</span>
        <span class="tag label">Tag 1</span>
        <span class="tag label">Tag 1</span>
    </div>
</div>