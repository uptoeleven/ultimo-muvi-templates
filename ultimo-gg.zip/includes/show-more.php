<div class="show-more position-relative text-uppercase text-center">
    <a href="#" class="text-reset d-block">
        <div class="font-xxs">Show more</div> 
        <i class="fa fa-angle-down position-absolute font-xxs" aria-hidden="true"></i>
    </a>
</div>