<div class="col-sm-6 col-md-3 mb-4 text-uppercase">
    <div class="position-relative">
        <div class="position-absolute w-100 h-100 stream-img-overlay"></div>
        <img src="images/stream-cat-img-04.jpg" class="img-responsive">
        <div class="position-absolute live-badge">
            <img src="images/icons/streaming-red.svg">
            <span>Live</span>
        </div>
    </div>
    <div class="spacer1 mb-1"></div>
    <div class="font-bold">Clip name goes here</div>
    <div class="d-flex flex-between">
        <div>
            <span class="tag label">Tag 1</span>
            <span class="tag label">Tag 1</span>
            <span class="tag label">Tag 1</span>
        </div>
        <div class="d-flex align-items-center like font-sm">
            <img class="mr-2" src="images/icons/flame.svg">
        <div class="font-bold">538</div>
        </div>
    </div>
</div>