<div class="spacer2"></div>
    <div class="d-flex flex-between">
        <div>
            <a href="#" class="d-inline-flex text-uppercase text-reset mr-2 btn btn-main active">All streams</a>
            <a href="#" class="d-inline-flex text-uppercase text-reset btn btn-main">By game</a>
        </div>
        <div class="dropdown">
            <a class="btn text-uppercase text-reset btn btn-filter" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
            Filter option
                <i class="fa fa-angle-down ml-2" aria-hidden="true"></i>
            </a>
            <ul class="dropdown-menu dropdown-menu-right font-sm" aria-labelledby="dropdownMenu1">
                <li><a class="text-reset" href="#">Option</a></li>
                <li role="separator" class="divider opacity-10"></li>
                <li><a class="text-reset" href="#">Option</a></li>
                <li role="separator" class="divider opacity-10"></li>
                <li><a class="text-reset" href="#">Option</a></li>
                <li role="separator" class="divider opacity-10"></li>
                <li><a class="text-reset" href="#">Option</a></li>
            </ul>
        </div>
    </div>
<div class="spacer3"></div>