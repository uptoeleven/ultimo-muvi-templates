<div class="d-flex justify-content-between pr-3 pr-md-5 mb-3">
    <div class="achievement achievement-1 d-flex flex-center"></div>
    <div class="achievement achievement-1 d-flex flex-center"></div>
    <div class="achievement achievement-1 d-flex flex-center"></div>
    <div class="achievement achievement-1 d-flex flex-center"></div>
    <div class="achievement achievement-1 d-flex flex-center disabled"></div>
    <div class="achievement achievement-1 d-flex flex-center disabled"></div>
    <div class="achievement achievement-1 d-flex flex-center disabled"></div>
    <div class="achievement achievement-1 d-flex flex-center disabled"></div>
    <div class="achievement achievement-1 d-flex flex-center disabled"></div>
    <div class="achievement achievement-1 d-flex flex-center disabled"></div>
    <div class="achievement achievement-1 d-flex flex-center disabled"></div>
    <div class="achievement achievement-1 d-flex flex-center disabled"></div>
    <div class="achievement achievement-1 d-flex flex-center disabled"></div>
    <div class="achievement achievement-1 d-flex flex-center disabled"></div>
    <div class="achievement achievement-1 d-flex flex-center disabled"></div>
</div>
<div class="d-flex justify-content-between pr-3 pr-md-5 mb-3">
    <div class="achievement achievement-2 d-flex flex-center"></div>
    <div class="achievement achievement-2 d-flex flex-center"></div>
    <div class="achievement achievement-2 d-flex flex-center"></div>
    <div class="achievement achievement-2 d-flex flex-center"></div>
    <div class="achievement achievement-2 d-flex flex-center"></div>
    <div class="achievement achievement-2 d-flex flex-center disabled"></div>
    <div class="achievement achievement-2 d-flex flex-center disabled"></div>
    <div class="achievement achievement-2 d-flex flex-center disabled"></div>
    <div class="achievement achievement-2 d-flex flex-center disabled"></div>
    <div class="achievement achievement-2 d-flex flex-center disabled"></div>
    <div class="achievement achievement-2 d-flex flex-center disabled"></div>
    <div class="achievement achievement-2 d-flex flex-center disabled"></div>
    <div class="achievement achievement-2 d-flex flex-center disabled"></div>
    <div class="achievement achievement-2 d-flex flex-center disabled"></div>
    <div class="achievement achievement-2 d-flex flex-center disabled"></div>
</div>
<div class="d-flex justify-content-between pr-3 pr-md-5 mb-3">
    <div class="achievement achievement-3 d-flex flex-center"></div>
    <div class="achievement achievement-3 d-flex flex-center"></div>
    <div class="achievement achievement-3 d-flex flex-center"></div>
    <div class="achievement achievement-3 d-flex flex-center"></div>
    <div class="achievement achievement-3 d-flex flex-center disabled"></div>
    <div class="achievement achievement-3 d-flex flex-center disabled"></div>
    <div class="achievement achievement-3 d-flex flex-center disabled"></div>
    <div class="achievement achievement-3 d-flex flex-center disabled"></div>
    <div class="achievement achievement-3 d-flex flex-center disabled"></div>
    <div class="achievement achievement-3 d-flex flex-center disabled"></div>
    <div class="achievement achievement-3 d-flex flex-center disabled"></div>
    <div class="achievement achievement-3 d-flex flex-center disabled"></div>
    <div class="achievement achievement-3 d-flex flex-center disabled"></div>
    <div class="achievement achievement-3 d-flex flex-center disabled"></div>
    <div class="achievement achievement-3 d-flex flex-center disabled"></div>
</div>
<div class="d-flex justify-content-between pr-3 pr-md-5 mb-3">
    <div class="achievement achievement-1 d-flex flex-center"><img src="images/icons/achievement-01.svg"> </div>
    <div class="achievement achievement-1 d-flex flex-center"><img src="images/icons/achievement-01.svg"> </div>
    <div class="achievement achievement-1 d-flex flex-center"><img src="images/icons/achievement-01.svg"> </div>
    <div class="achievement achievement-1 d-flex flex-center"><img src="images/icons/achievement-01.svg"> </div>
    <div class="achievement achievement-1 d-flex flex-center disabled"><img src="images/icons/achievement-01.svg"> </div>
    <div class="achievement achievement-1 d-flex flex-center disabled"><img src="images/icons/achievement-01.svg"> </div>
    <div class="achievement achievement-1 d-flex flex-center disabled"><img src="images/icons/achievement-01.svg"> </div>
    <div class="achievement achievement-1 d-flex flex-center disabled"><img src="images/icons/achievement-01.svg"> </div>
    <div class="achievement achievement-1 d-flex flex-center disabled"><img src="images/icons/achievement-01.svg"> </div>
    <div class="achievement achievement-1 d-flex flex-center disabled"><img src="images/icons/achievement-01.svg"> </div>
    <div class="achievement achievement-1 d-flex flex-center disabled"><img src="images/icons/achievement-01.svg"> </div>
    <div class="achievement achievement-1 d-flex flex-center disabled"><img src="images/icons/achievement-01.svg"> </div>
    <div class="achievement achievement-1 d-flex flex-center disabled"><img src="images/icons/achievement-01.svg"> </div>
    <div class="achievement achievement-1 d-flex flex-center disabled"><img src="images/icons/achievement-01.svg"> </div>
    <div class="achievement achievement-1 d-flex flex-center disabled"><img src="images/icons/achievement-01.svg"> </div>
</div>
<div class="d-flex justify-content-between pr-3 pr-md-5 mb-3">
    <div class="achievement achievement-2 d-flex flex-center"><img src="images/icons/achievement-02.svg"> </div>
    <div class="achievement achievement-2 d-flex flex-center"><img src="images/icons/achievement-02.svg"> </div>
    <div class="achievement achievement-2 d-flex flex-center"><img src="images/icons/achievement-02.svg"> </div>
    <div class="achievement achievement-2 d-flex flex-center"><img src="images/icons/achievement-02.svg"> </div>
    <div class="achievement achievement-2 d-flex flex-center"><img src="images/icons/achievement-02.svg"> </div>
    <div class="achievement achievement-2 d-flex flex-center disabled"><img src="images/icons/achievement-02.svg"> </div>
    <div class="achievement achievement-2 d-flex flex-center disabled"><img src="images/icons/achievement-02.svg"> </div>
    <div class="achievement achievement-2 d-flex flex-center disabled"><img src="images/icons/achievement-02.svg"> </div>
    <div class="achievement achievement-2 d-flex flex-center disabled"><img src="images/icons/achievement-02.svg"> </div>
    <div class="achievement achievement-2 d-flex flex-center disabled"><img src="images/icons/achievement-02.svg"> </div>
    <div class="achievement achievement-2 d-flex flex-center disabled"><img src="images/icons/achievement-02.svg"> </div>
    <div class="achievement achievement-2 d-flex flex-center disabled"><img src="images/icons/achievement-02.svg"> </div>
    <div class="achievement achievement-2 d-flex flex-center disabled"><img src="images/icons/achievement-02.svg"> </div>
    <div class="achievement achievement-2 d-flex flex-center disabled"><img src="images/icons/achievement-02.svg"> </div>
    <div class="achievement achievement-2 d-flex flex-center disabled"><img src="images/icons/achievement-02.svg"> </div>
</div>
<div class="d-flex justify-content-between pr-3 pr-md-5 mb-3">
    <div class="achievement achievement-3 d-flex flex-center"><img src="images/icons/achievement-03.svg"> </div>
    <div class="achievement achievement-3 d-flex flex-center"><img src="images/icons/achievement-03.svg"> </div>
    <div class="achievement achievement-3 d-flex flex-center"><img src="images/icons/achievement-03.svg"> </div>
    <div class="achievement achievement-3 d-flex flex-center"><img src="images/icons/achievement-03.svg"> </div>
    <div class="achievement achievement-3 d-flex flex-center disabled"><img src="images/icons/achievement-03.svg"> </div>
    <div class="achievement achievement-3 d-flex flex-center disabled"><img src="images/icons/achievement-03.svg"> </div>
    <div class="achievement achievement-3 d-flex flex-center disabled"><img src="images/icons/achievement-03.svg"> </div>
    <div class="achievement achievement-3 d-flex flex-center disabled"><img src="images/icons/achievement-03.svg"> </div>
    <div class="achievement achievement-3 d-flex flex-center disabled"><img src="images/icons/achievement-03.svg"> </div>
    <div class="achievement achievement-3 d-flex flex-center disabled"><img src="images/icons/achievement-03.svg"> </div>
    <div class="achievement achievement-3 d-flex flex-center disabled"><img src="images/icons/achievement-03.svg"> </div>
    <div class="achievement achievement-3 d-flex flex-center disabled"><img src="images/icons/achievement-03.svg"> </div>
    <div class="achievement achievement-3 d-flex flex-center disabled"><img src="images/icons/achievement-03.svg"> </div>
    <div class="achievement achievement-3 d-flex flex-center disabled"><img src="images/icons/achievement-03.svg"> </div>
    <div class="achievement achievement-3 d-flex flex-center disabled"><img src="images/icons/achievement-03.svg"> </div>
</div>