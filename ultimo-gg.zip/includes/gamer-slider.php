<div class="d-flex flex-center flex-column">
    <img src="images/gamer.jpg" class="rounded-circle gamer-img mb-2">
    <h6 class="pt-1">Gamertag1</h6>
    <a href="#" class="stretched-link"></a>
</div>