<?php require_once('includes/header.php'); ?>

<div class="w-100 profile-banner" style="background-image: url('images/banner-img.jpg');"></div>

<div class="spacer2"></div>

<div class="container">
    <div class="row">
        <div class="col-xs-12 col-sm-9 col-md-6 mb-4 mb-md-0">
            <div class="row">
                <div class="col-xs-12 col-sm-4">
                    <div class="profile-img-lg position-relative rounded-circle mx-auto">
                        <img src="images/user-image.jpg" class="rounded-circle position-absolute">
                    </div>
                </div>
                <div class="col-xs-12 col-sm-8">
                    <div class="ml-md-4 text-uppercase">
                        <div class="spacer2 d-md-none"></div>
                        <h3 class="font-xbold mb-2">Player User name</h3>
                        <div class="live-badge">
                            <img src="images/icons/streaming-red.svg">
                            <span>Live</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xs-12 col-sm-3 col-md-6">
            <div class="d-flex justify-content-md-end text-uppercase font-xs">
                <div>Global rank</div>
                <div class="mx-3">2039</div>
                <img src="images/icons/rank.svg">
            </div>
        </div>
    </div>
    <div class="spacer3"></div>
    <div class="row">
        <div class="col-xs-12 col-sm-9 col-md-6">
            <div class="row">
                <div class="col-xs-4">
                    <div class="stats stats-lg d-flex flex-center mx-auto">
                        <h2 class="font-xbold">45</h2>    
                    </div>
                </div>
                <div class="col-xs-8">
                    <div class="font-bold text-uppercase mt-4">
                        <div class="font-sm mb-2">Rank name</div>
                        <div class="d-flex flex-between">
                            <h6 class="text-secondary">xp</h6>
                            <h6 class="text-secondary">4569/9564</h6>
                        </div>
                        <div class="progress progress-lg shadow-none mb-0 my-2">
                            <div class="progress-bar shadow-none" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 40%;">
                            <span class="sr-only">40%</span>
                            </div>
                        </div>
                        <div class="d-flex flex-between">
                            <div class="text-secondary">45</div>
                            <div class="text-secondary">46</div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mt-3 mb-2">
                <div class="col-xs-4 text-center">
                    <div class="font-bold font-xs text-uppercase">Rank</div>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-4 text-center">
                    <div class="d-flex justify-content-center">
                        <div class="achievement achievement-sm achievement-1 d-flex flex-center">
                            <img src="images/icons/achievement-01.svg"> 
                        </div>
                        <div class="achievement achievement-sm achievement-2 d-flex flex-center mx-2">
                            <img src="images/icons/achievement-02.svg"> 
                        </div>
                        <div class="achievement achievement-sm achievement-3 d-flex flex-center">
                            <img src="images/icons/achievement-03.svg"> 
                        </div>
                    </div>
                </div>
                <div class="col-xs-8">
                    <div class="row font-bold text-uppercase">
                        <div class="col-xs-8 font-xs">
                            <span class="mr-5">Last seen</span>
                            <span>13 hours</span>
                        </div>
                        <div class="col-xs-4 font-xxs location">
                            <div class="mb-2">Idaho, United States</div>
                            <div>156th</div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="spacer3"></div>
            <img src="images/map.png" class="img-responsive w-100">
        </div>
        <div class="col-xs-12 col-sm-3 col-md-offset-2 mt-5">
            <img src="images/user-player-img.png" class="img-responsive mx-auto">
        </div>
    </div>
    <div class="spacer5"></div>
    <h3 class="font-xbold text-uppercase">Achievements</h3>
    <div class="spacer2"></div>
    <div class="row text-uppercase">
        <div class="col-xs-12 col-sm-6">
            <div class="font-xbold font-xs text-secondary mb-2">Achievements title</div>
            <h6 class="font-bold">Consectetur</h6>
        </div>
        <div class="col-xs-12 col-sm-6 col-md-5 mt-5 mt-md-0">
            <div class="d-flex flex-between font-bold font-xs">
                <div class="d-flex">
                    <div>Global rank</div>
                    <div class="mx-1 mx-sm-3">2039</div>
                    <img src="images/icons/rank.svg">
                </div>
                <div class="d-flex">
                    <div class="mr-1 mr-sm-3">Statistic 2</div>
                    <div>2039</div>
                </div>
                <div class="d-flex">
                    <div class="mr-1 mr-sm-3">Statistic 3</div>
                    <div>2039</div>
                </div>
            </div>
        </div>
    </div>
    <div class="spacer3"></div>
    <div class="row">
        <div class="col-xs-8 col-xs-offset-2 col-sm-8 col-md-7 col-sm-offset-2">
            <div class="achievement-slider owl-carousel">
                <div class="d-flex flex-column flex-md-row justify-content-md-between align-items-md-center">
                    <div class="d-flex flex-between">
                        <div class="achievement achievement-lg achievement-1 d-flex flex-center mr-3 mr-md-5">
                            <img src="images/icons/achievement-01.svg">
                        </div>
                        <div class="text-uppercase">
                            <div class="font-xbold font-sm text-secondary mb-2">Game achievement</div>
                            <h6 class="font-bold">1000 Xp</h6>
                        </div>
                    </div>
                    <h6 class="font-bold mt-4 mt-md-0">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor </h6>
                </div>
                <div class="d-flex flex-column flex-md-row justify-content-md-between align-items-md-center">
                    <div class="d-flex flex-between">
                        <div class="achievement achievement-lg achievement-1 d-flex flex-center mr-3 mr-md-5">
                            <img src="images/icons/achievement-01.svg">
                        </div>
                        <div class="text-uppercase">
                            <div class="font-xbold font-sm text-secondary mb-2">Game achievement</div>
                            <h6 class="font-bold">1000 Xp</h6>
                        </div>
                    </div>
                    <h6 class="font-bold mt-4 mt-md-0">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor </h6>
                </div>
                <div class="d-flex flex-column flex-md-row justify-content-md-between align-items-md-center">
                    <div class="d-flex flex-between">
                        <div class="achievement achievement-lg achievement-1 d-flex flex-center mr-3 mr-md-5">
                            <img src="images/icons/achievement-01.svg">
                        </div>
                        <div class="text-uppercase">
                            <div class="font-xbold font-sm text-secondary mb-2">Game achievement</div>
                            <h6 class="font-bold">1000 Xp</h6>
                        </div>
                    </div>
                    <h6 class="font-bold mt-4 mt-md-0">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor </h6>
                </div>
            </div>
        </div>
    </div>
    <div class="spacer4"></div>
    <div class="achievement-holder overflow-auto">
        <?php require_once('includes/achievement-holder.php'); ?>
    </div>
</div>

<div class="spacer3"></div>

<div class="container">
  <hr class="my-0 opacity-10">
</div>

<div class="container">
    <div class="spacer3"></div>
    <div class="d-flex flex-between">
        <h3 class="text-uppercase">Streamer clips</h3>
        <img src="images/icons/play.svg">
    </div>
    <?php include('includes/stream-grid-top-section.php'); ?>
    <div class="row d-flex d-md-block row-grid mb-4 pb-1 pb-md-0">
        <?php include('includes/stream-grid-simple.php'); ?>
        <?php include('includes/stream-grid-simple.php'); ?>
        <?php include('includes/stream-grid-simple.php'); ?>
        <?php include('includes/stream-grid-simple.php'); ?>
    </div>
    <?php include('includes/show-more.php'); ?>
</div>

<div class="container">
    <div class="spacer3"></div>
    <div class="d-flex flex-between">
        <h3 class="text-uppercase">More streams</h3>
        <div class="streaming-icon"></div>
    </div>
    <?php include('includes/stream-grid-top-section.php'); ?>
    <div class="row d-flex d-md-block row-grid mb-4 pb-1 pb-md-0">
        <?php include('includes/stream-grid.php'); ?>
        <?php include('includes/stream-grid.php'); ?>
        <?php include('includes/stream-grid.php'); ?>
        <?php include('includes/stream-grid.php'); ?>
    </div>
    <?php include('includes/show-more.php'); ?>
</div>

<div class="container">
    <div class="spacer3"></div>
    <h3 class="text-uppercase">Streamer Products</h3>
    <div class="spacer3"></div>
    <div class="row d-flex d-md-block row-grid mb-4 pb-1 pb-md-0">
        <?php include('includes/products.php'); ?>
        <?php include('includes/products.php'); ?>
        <?php include('includes/products.php'); ?>
        <?php include('includes/products.php'); ?>
    </div>
    <?php include('includes/show-more.php'); ?>
</div>

<div class="spacer4"></div>

<?php require_once('includes/footer.php'); ?>